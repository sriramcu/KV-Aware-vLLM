# Modular VPC diagnostics + hindsight oracle — v2

Patch baseline: latest user-uploaded
KV-Aware-vLLM-lmcache-mp-l0-vllm029(2)(2).zip (2026-10-09).

Choose EXACTLY ONE patch (do not apply both):

 A) New checkout matching the uploaded repository:
    git apply --check /path/to/vpc_diagnostics_oracle_modular_v2_full.patch
    git apply /path/to/vpc_diagnostics_oracle_modular_v2_full.patch

 B) Repo with the PRIOR v1 vpc_diagnostics_hindsight_oracle_v1.patch
    already successfully applied:
    git apply --check /path/to/vpc_diagnostics_oracle_modular_v2_from_v1.patch
    git apply /path/to/vpc_diagnostics_oracle_modular_v2_from_v1.patch

These patch paths are in this ZIP. changed_files/ is a fallback full tree.

Place the budget-independent Q650 rank JSON in persistent GPFS, NOT
/scratch2/sriramc2 (CLEAN_OLD_LMCACHE may delete that scratch area).
The asset is packaged at
   experiments/oracle_rankings/q650_hindsight_frequency_rank_29358.json
inside this ZIP. Extract this path into your checkout:
   unzip -o /path/to/vpc_diagnostics_oracle_modular_v2_bundle.zip \
     'experiments/oracle_rankings/*' -d .

For future oracle runs, opt in explicitly:
    KV_CHUNK_PLACEMENT_MODE=oracle
    VLLM_VPC_POLICY=selective
    KV_ORACLE_RANKING_FILE=/mnt/shared/gpfs/home/sriramc2/KV-Aware-vLLM/experiments/oracle_rankings/q650_hindsight_frequency_rank_29358.json
    KV_ORACLE_GPU_CHUNKS=258
    KV_ORACLE_CPU_CHUNKS=767
    KV_ORACLE_DISK_CHUNKS=1012
Oracle is DISABLED by default. Selective admission uses normal LRU reclaims,
not GPU KV pinning or KV preloading. Re-budget by varying the count controls.

Enable diagnostics in Q650 sweep as needed:
    VLLM_VPC_DIAGNOSTICS=1
    VLLM_VPC_DIAG_INTERVAL_S=5
The JSONL shape is unchanged from v1. New runtime lifecycle lives in
vllm/v1/core/vpc_policies/runtime_diagnostics.py, not block_pool.py.

Validation: git apply checked and byte-for-byte verified from BOTH baselines;
Python compilation, bash -n and 6 standalone pure tests passed.
Full compiled vLLM/inference integration not available here; run the actual
vLLM policy + diagnostic tests and L40/H100 smoke before benchmark.
