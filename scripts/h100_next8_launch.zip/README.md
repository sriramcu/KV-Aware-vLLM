# H100 next-eight paired stress/generalization experiments

This package submits eight H100 jobs (four matched pairs) using the **existing
patched 10-batch safe launchers**, cloning them rather than overwriting them.

## Install on CodeNimbus login node

```bash
cd /mnt/shared/gpfs/home/sriramc2/KV-Aware-vLLM
unzip -o ~/h100_next8_launch.zip -d .
python scripts/h100_next8/install.py --repo "$PWD"
```

Do **not** rerun the old 10-batch installer: it may undo the manual expected-
ordinal `KV_BAYES_SCORE_FORMAT` fix. The new installer reads the already-installed
and already-patched `scripts/h100_10batch/*_safe.sbatch` files, verifies physical
L2-capacity enforcement, and creates new variable-dataset/Q/B copies under
`scripts/h100_next8`.

## Data checks worth running *before* spending queue time

```bash
python scripts/h100_next8/preflight_dataset.py --repo "$PWD" --dataset medical --questions 1000 --policy bayes
python scripts/h100_next8/preflight_dataset.py --repo "$PWD" --dataset hotpotqa --questions 650 --policy bayes
```

The HotpotQA test requires the **LinearRAG import** assets:
`Hierarchical_KV/LinearRAG/import/hotpotqa/LinearRAG.graphml`,
`passage_embedding.parquet`, `entity_embedding.parquet`, and
`Hierarchical_KV/LinearRAG/dataset/hotpotqa/questions.json`.
Having only top-level `dataset/hotpotqa/chunks.json` and questions is insufficient.
The batch wrapper repeats these checks *before deleting scratch* and fails
with a clear error if assets are absent. Q1000 also requires at least 1000
medical questions.

## Submit all eight (or submit individual lines)

```bash
bash scripts/h100_next8/submit_8_sbatch_only.sh
```

`submit_8_sbatch_only.sh` consists of **exactly eight `sbatch` commands** and
nothing else. The same job name `kvq650-10batch` as the previous queue is used
on purpose: Slurm `singleton` serializes these jobs with the remaining P11
job 29958 and prevents concurrent full-root scratch cleanups. Queuing now
is fine; these eight wait for that running job to finish. `singleton` does not
block on a previous job's failure (unlike `afterok`). Other jobs sharing
scratch under another job name are NOT protected.

## Grid

| Case | Policy | Dataset | Q | B | GPU policy GiB | L1 GiB | L2 GiB | Posterior | PUT cap GiB |
|---|---|---|---:|---:|---:|---:|---:|---|---:|
| B200_NG | No-GNN | medical | 650 | 200 | n/a | 225 | 500 | n/a | 0.25 |
| B200_BY | Bayes | medical | 650 | 200 | 25 | 225 | 500 | fixed w=0.5 | 0.25 |
| CPU100_NG | No-GNN | medical | 650 | 100 | n/a | 100 | 400 | n/a | 0.25 |
| CPU100_BY | Bayes | medical | 650 | 100 | 25 | 100 | 400 | fixed w=0.5 | 0.25 |
| HOTPOT_NG | No-GNN | hotpotqa | 650 | 100 | n/a | 225 | 500 | n/a | 0.25 |
| HOTPOT_BY | Bayes | hotpotqa | 650 | 100 | 25 | 225 | 500 | fixed w=0.5 | 0.25 |
| Q1000_NG | No-GNN | medical | 1000 | 100 | n/a | 225 | 500 | n/a | 0.25 |
| Q1000_BY | Bayes | medical | 1000 | 100 | 25 | 225 | 500 | fixed w=0.5 | 0.25 |

All use Llama-3.3-70B FP8 TP2 on 2×H100, 16 CPUs, max_num_seqs16, 512-token
chunks, 128 output tokens, original passage ordering, cold seeded_shuffle seed0,
warm random seed1, and full cold-to-warm store barrier. The score prior remains
`runs/kvaware/h100_expected_ordinal_exploratory.json` with
`expected_ordinal_0_100` score format. The historical medical prior is kept
frozen for HotpotQA, so Hotpot is an exploratory transfer experiment.

## Cleanup and results

`CLEAN_OLD_LMCACHE=1` is set for **all eight** jobs. Before the workload, it
removes everything *under* `/scratch2/sriramc2` and preserves the root. Results
and logs are saved under GPFS `/mnt/shared/gpfs/home/sriramc2/runs/kvaware`.
Cache files left by the last job remain until the next full cleanup.

Output logs: `/mnt/shared/gpfs/home/sriramc2/runs/kvaware/kvq650-10batch_<JOB_ID>.out`.
Run folder names contain the unique `next8_<CASE_ID>` label and job ID.

There is no `--mem` directive. Each job requests 2 GPUs and 16 CPUs, 6 hours.

### Methodology

- The Q1000 run changes both number of questions and number of Bayesian
  posterior waves (ten per phase instead of seven); it is not a pure capacity
  perturbation.
- The B200 run also changes the Bayesian wave count (four per phase instead of
  seven) and instantaneous concurrency, not only memory pressure.
- The HotpotQA run is only interpretable if its retrieval/graph assets and
  query population are valid, and the medical-derived prior is not retuned.
- No-GNN has no Bayesian GPU policy quota. Its real vLLM GPU allocation is kept
  the same as its paired Bayesian counterpart.
- The launcher retains the capped PUT, avoiding the demonstrated uncapped
  no-GNN `/status` read-timeout failure mechanism.
